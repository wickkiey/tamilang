# TamiLang

## Phonetic Translation

This package helps to reac tamil through english phonetics. 
It will be helpful for people who wants to learn tamil through english. 

## Command line usage

`python -m tamilang "tamilword"`

